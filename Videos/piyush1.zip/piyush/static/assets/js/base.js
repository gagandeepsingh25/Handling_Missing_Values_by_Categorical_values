$(document).ready(function(){
//    Script start
    $('#template-customizer').addClass('d-none');
//    Script end    
});