from django.apps import AppConfig


class LlamaAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'llama_app'
