<?php
	/**
	* Plugin Name: SecureChat
	* Plugin URI: https://securechat.ai/
	* Description: This Pulgin is created for the chatbot.
	* Version: 0.1
	* Author: SecureChat Ai
	* Author URI: https://securechat.ai/
	**/

	// Function to be executed during the 'init' action

	define('PREFIX', 'expcht_');
	define('PLUGIN_PATH', plugins_url('',__FILE__ ));
	define('PLUGIN_ASSETS_PATH', PLUGIN_PATH .'/assests');	
	class Chatbot
	{
		public function __construct()
		{
			add_action('admin_menu', array($this, 'custom_menu_page'));
			add_action("admin_init", array($this, "display_chatbox_panel_fields"));
			add_action('wp_footer',  array($this,'custom_plugin_footer_script'),10);
			
		}
		
		public function custom_menu_page() {
			add_submenu_page(
					'options-general.php',     // Page Title
					'SecureChat',   
					'SecureChat',				// Menu Title
					'manage_options',  // Capability required to access
					'chat_box',     // Menu Slug
					array($this,'ChatBox_page_content'), // Callback function to display the page content
					'dashicons-admin-tools', // Icon for the menu item (you can change this)
					20 // Position in the admin menu
				);
			}


			
		public function ChatBox_page_content() {
		?>
		<style>
			h2 {
				display: none;
			}

			.wrap {
				margin-top: 30px;
			}

			.iframe_Style_section {
				display: none;
			}

			.form-table th {
				vertical-align: middle;
			}
		
		</style>
	<div class="wrap">
	
	    <div><img src="<?php echo PLUGIN_ASSETS_PATH; ?>/media/image_logo.png">
	        <div>
	            <div>
	                <h3><b>SecureChat chatbot integration</b></h3>
	            </div>
	            <div>
	                <p>Provide information for Chatbot integration on your WordPress website.</p>
	            </div>
	            <form method="post" action="options.php">
	                <?php
							settings_fields( 'Chatbox_id-group' );
							do_settings_sections( 'Chatbox_id-group' );
							submit_button();
					?>
	            </form>
	        </div>

	        <script>
	        jQuery(document).ready(function() {

	            if (jQuery('#embad_option').val() == "Iframe") {
	                jQuery('.iframe_Style_section').css('display', 'table-row');
	                jQuery('.iframe_style').css('display', 'flex');
				}
	            // }else{
				// 	jQuery('.iframe_Style_section').css('display', 'none');
	            //     jQuery('.iframe_style').css('display', 'none');
				// }
	        });


	        jQuery('#embad_option').on('change', function() {

	            if (jQuery(this).val() == "Iframe") {
	                jQuery('.iframe_Style_section').css('display', 'table-row');
	                jQuery('.iframe_style').css('display', 'flex');
	            } else {
	                jQuery('.iframe_Style_section').css('display', 'none');
	                jQuery('.iframe_style').css('display', 'none');
	            }


	        });
	        </script>
	        <?php
		}
		public function display_chatbox_panel_fields(){
			add_settings_section("Chatbox-id-group", "ChatBox", null, "Chatbox_id-group");
			add_settings_field("chat_box_id", "Chatbot Id", array($this, "chat_box_input"), "Chatbox_id-group", "Chatbox-id-group");

			add_settings_field("chat_box_domain", "Chatbot domain", array($this, "chat_box_domaine_input"), "Chatbox_id-group", "Chatbox-id-group");


			add_settings_field("chat_box_embad_option", "Chatbot Option", array($this, "chat_box_select"), "Chatbox_id-group", "Chatbox-id-group");
			add_settings_field("chat_box_iframe_style", "Iframe Chatbot Style", array($this, "chat_box_input_style"), "Chatbox_id-group", "Chatbox-id-group",array("class"=>"iframe_Style_section"));
			register_setting( 'Chatbox_id-group', PREFIX.'Chatbox_id' );  
			register_setting( 'Chatbox_id-group', PREFIX.'Chatbox_domine' );  
			register_setting( 'Chatbox_id-group', PREFIX.'Chatbox_embad_option' );
			register_setting( 'Chatbox_id-group', PREFIX.'Chatbox_iframe_style' );       
				
		}
		function chat_box_input()
		{
			?>
	        <div style="display:table-caption;">
	            <label>Enter SecureChat chatbot id</label>
	            <input name="<?php echo PREFIX.'Chatbox_id'?>" class="chat_box_inputs" type="text"
	                value="<?php echo get_option(PREFIX.'Chatbox_id'); ?>">
	        </div>
	        <?php
		}
		
		function chat_box_domaine_input(){
			?>
	        <div style="display:table-caption;">
	            <label>Enter SecureChat chatbot domain</label>
	            <input name="<?php echo PREFIX.'Chatbox_domine'?>" class="chat_box_inputs" type="text"
	                value="<?php echo get_option(PREFIX.'Chatbox_domine'); ?>">
	        </div>
	        <?php	
		}
		public function chat_box_select(){
		?>
	        <div style="display:grid;">
	            <label>Enter Select chatbot option</label>
	            <select name="<?php echo PREFIX.'Chatbox_embad_option'?>" id="embad_option" style="width: 20%;">
	                <option value="Iframe"
	                    <?php echo (get_option(PREFIX.'Chatbox_embad_option') == 'Iframe')?'selected':''; ?>>Iframe
	                </option>
	                <option value="script"
	                    <?php echo (get_option(PREFIX.'Chatbox_embad_option') == 'script')?'selected':''; ?>>Script
	                </option>
	            </select>
	        </div>
	        <?php
		}
		
		public function chat_box_input_style(){ 
		
		?>
	        <div class="iframe_style" style="display:none;">
	            <div class="main_input" style="display:flex; justify-content:flex-start; align-items:flex-start; padding-right: 30px;text-align: center; flex-direction: column;">
	                <label style="margin-bottom:5px;">Width</label>
	                <span>
	                    <input type="number" min="1" max="100" name="<?php echo PREFIX.'Chatbox_iframe_style'; ?>[width]"
	                        value="<?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['width']) && get_option(PREFIX.'Chatbox_iframe_style')['width'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['width']:100; ?>">
	                    <select name="<?php echo PREFIX; ?>Chatbox_iframe_style[width_dimention]" style="margin-bottom:3px;">
	                        <option value="%"
	                            <?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['width_dimention']) && get_option(PREFIX.'Chatbox_iframe_style')['width_dimention'] == '%')?'selected':''; ?>>
	                            %</option>
	                        <option value="px"
	                            <?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['width_dimention']) && get_option(PREFIX.'Chatbox_iframe_style')['width_dimention'] == 'px')?'selected':''; ?>>
	                            px</option>
	                    </select>
	                </span>
	            </div>
	            <div class="main_input" style="display:flex; justify-content:flex-start; align-items:flex-start;padding-right: 30px;text-align: center; flex-direction: column;" >
	                <label style="margin-bottom:5px;">Height</label>
					
	                <span>
	                    <input type="number" min="1" max="900" name="<?php echo PREFIX.'Chatbox_iframe_style'; ?>[height]"
	                        value="<?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['height']) && get_option(PREFIX.'Chatbox_iframe_style')['height'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['height']:700; ?>">
	                    <select name="<?php echo PREFIX; ?>Chatbox_iframe_style[height_dimention]" style="margin-bottom:3px;">
	                        <option value="px"
	                            <?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['height_dimention']) && get_option(PREFIX.'Chatbox_iframe_style')['height_dimention'] == 'px')?'selected':''; ?>>
	                            px</option>
	                        <option value="%"
	                            <?php echo (isset(get_option(PREFIX.'Chatbox_iframe_style')['height_dimention']) && get_option(PREFIX.'Chatbox_iframe_style')['height_dimention'] == '%')?'selected':''; ?>>
	                            %</option>
	                    </select>


	                </span>
	            </div>
	        </div>



	        <?php
			
			
		}

		public function custom_plugin_footer_script(){
			if(get_option(PREFIX.'chatbox_id') != '' && get_option(PREFIX.'Chatbox_embad_option') == 'script'){
				?>
	        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	        <script src="https://<?php echo esc_attr( get_option(PREFIX.'Chatbox_domine') )?>/static/assets/js/updated-chatbot-loader.js"
	            chatbot-id="<?php esc_attr( get_option(PREFIX.'Chatbox_id') )?>" type="application/javascript"></script>
	        <?php
	}   else   if(get_option(PREFIX.'chatbox_id') != '' && get_option(PREFIX.'Chatbox_embad_option') == 'Iframe'){
		?>
	        <iframe src="https://<?php echo esc_attr( get_option(PREFIX.'Chatbox_domine') )?>/chatbot-iframe/<?php echo esc_attr( get_option(PREFIX.'Chatbox_id') )?>"
	            frameborder="0" scrolling="no"
	            width="<?php echo (get_option(PREFIX.'Chatbox_iframe_style')['width'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['width']:100; ?><?php echo (get_option(PREFIX.'Chatbox_iframe_style')['width_dimention'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['width_dimention']:'%'; ?>"
	            height="<?php echo (get_option(PREFIX.'Chatbox_iframe_style')['height'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['height']:700; ?><?php echo (get_option(PREFIX.'Chatbox_iframe_style')['height_dimention'] != '') ? get_option(PREFIX.'Chatbox_iframe_style')['height_dimention']:'px'; ?>"></iframe>
	        <?php
	}
		
		}
	}
	$initiate = new Chatbot();